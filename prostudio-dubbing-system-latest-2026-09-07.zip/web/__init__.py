"""ProStudio web application."""
